package com.example.practica04.views

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.practica04.R
import com.example.practica04.navigation.ListaProductos
import com.example.practica04.navigation.Presentacion

val colorTextSecondary = Color(0xFFC5705D)
val colorBackground = Color(0xFFF8EDE3)
val colorHeader = Color(0xFF944E63)
@Composable
fun inicio(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colorBackground // Color de fondo claro
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            HeaderSection()

            // Imagen de perfil
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Spacer(modifier = Modifier.height(80.dp))
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(180.dp)
                        .clip(CircleShape)
                        .border(
                            width = 4.dp,
                            color = colorTextPrimary,
                            shape = CircleShape
                        ),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(90.dp))

            // Contenido principal
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "BonBon Tienda",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = colorHeader,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Botón para ir a la lista de productos
                    Button(
                        onClick = { navController.navigate(ListaProductos) }, // Navegar a ListaProductos
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colorHeader,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Productos")
                    }

                    // Botón para ir a la presentación
                    Button(
                        onClick = { navController.navigate(Presentacion) }, // Navegar a Presentación
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colorHeader,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Presentación")
                    }
                }

                // Footer
                FooterSection()
            }
        }
    }
}

@Composable
fun HeaderSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF944E63))
            .padding(35.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "INICIO",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun FooterSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Gray)
            .padding(15.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Arizaga Hernández Andrea Estefania",
            color = Color.White,
            fontFamily = FontFamily.Cursive,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 20.sp
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewInicio() {
    val navController = rememberNavController() // Crea un NavController simulado
    inicio(navController = navController)
}
